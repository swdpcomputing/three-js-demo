exports.handler = async (event) => {
  const environmentVariable = process.env.MESSAGE
  const response = {
    statusCode: 200,
    body: JSON.stringify(environmentVariable),
  };
  return response;
};
